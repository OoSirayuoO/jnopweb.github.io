vikramtiwari.github.io
======================

Github repo for Vikram Tiwari's Website

## How to get your own?
1. Fork the repo
2. Rename the repo as `your-user-name.github.com`
3. Check at [http://your-user-name.github.com](http://your-user-name.github.com)
4. Start making changes!

## How to run locally
Simply go to your cloned directory and start a static server:

1. Python 2.7x `python -m SimpleHTTPServer`
2. Python 3.x `python -m http.server`

> Don't forget to star the repo. :stuck_out_tongue_winking_eye:
